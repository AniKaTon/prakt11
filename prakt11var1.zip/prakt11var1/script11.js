 $(document).ready(function(){
	$('.dots').click(function () {
		 $(".dots.active").removeClass("active");
		$(this).addClass('active');
		});
		
		$('.dots#11').click(function () {
			$(".text")[0].innerHTML = "— 01";
		});
		
		$('.dots#12').click(function () {
			$(".text")[0].innerHTML = "— 02";
		});
		
		$('.dots#13').click(function () {
			$(".text")[0].innerHTML = "— 03";
		});
		
		$('.dots#14').click(function () {
			$(".text")[0].innerHTML = "— 04";
		});
	});
 
